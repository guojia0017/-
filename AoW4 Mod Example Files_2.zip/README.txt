This is official example content by Triumph Studios for Age of Wonders 4 released alongside the modding guide.

Example Content Files - contains example files for modding art related content

Massive Maps and 12 Players - mod that contains RMG overrides

Potato Spiders - mod that overrides spider models with custom potato models

TestNewTome - mod that contains the Tome of Penguins and contains all kinds of example resources.

AoW4_Modding.fspackage - the FMOD file used to mod audio in Age of Wonders 4

The example mods are playable, you can simply drop them in C:\Users\%username%\Documents\Paradox Interactive\Age of Wonders 4\Mods to access them in your launcher and enable them in a playset. Happy modding! :)